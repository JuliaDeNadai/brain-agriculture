"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("express-async-errors");
const api_1 = require("./api/api");
const port = 3000;
api_1.app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});

"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const supertest_1 = __importDefault(require("supertest"));
const api_1 = require("../../api/api");
const ruralProducerController_1 = require("../../controllers/ruralProducerController");
jest.mock('../../controllers/dashboardController');
describe('GET /ruralProducer/:cpf_cnpj', () => {
    let mockGetRuralProducer;
    beforeAll(() => {
        mockGetRuralProducer = jest.spyOn(ruralProducerController_1.RuralProducerController.prototype, 'get')
            .mockResolvedValue({
            id: 1,
            name: "Mocked name",
            cpf_cnpj: "99999999999",
            farm: {
                id: 1,
                name: "mocked farm name",
                city: "mocked city",
                state: "mocked state",
                totalArea: 10.0,
                arableArea: 8.0,
                vegetableArea: 2.0
            }
        });
    });
    afterAll(() => {
        mockGetRuralProducer.mockRestore();
    });
    it('should return rural producer data with status 200', () => __awaiter(void 0, void 0, void 0, function* () {
        const response = yield (0, supertest_1.default)(api_1.app).get('/api/ruralProducer/string');
        expect(response.status).toBe(200);
    }));
    it('should return rura producer data with all attributes', () => __awaiter(void 0, void 0, void 0, function* () {
        const response = yield (0, supertest_1.default)(api_1.app).get('/api/ruralProducer/string');
        expect(response.body).toHaveProperty('cpf_cnpj');
        expect(response.body).toHaveProperty('name');
        expect(response.body).toHaveProperty('farm');
    }));
});
describe('DELETE /ruralProducer/:cpf_cnpj', () => {
    let mockGetRuralProducer;
    beforeAll(() => {
        mockGetRuralProducer = jest.spyOn(ruralProducerController_1.RuralProducerController.prototype, 'delete')
            .mockResolvedValue(true);
    });
    afterAll(() => {
        mockGetRuralProducer.mockRestore();
    });
    it('should return status 204 on success', () => __awaiter(void 0, void 0, void 0, function* () {
        const response = yield (0, supertest_1.default)(api_1.app).delete('/api/ruralProducer/string');
        expect(response.status).toBe(204);
    }));
});

"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RuralProducerController = void 0;
const ruralProducerRepository_1 = require("../repositories/ruralProducerRepository");
const validateCPF_1 = require("../utils/validateCPF");
const validateCNPJ_1 = require("../utils/validateCNPJ");
const producerRepository_1 = require("../repositories/producerRepository");
const farmRepository_1 = require("../repositories/farmRepository");
const farmCropRepository_1 = require("../repositories/farmCropRepository");
class RuralProducerController {
    constructor() {
        this.ruralProducerRepository = new ruralProducerRepository_1.RuralProducerRepository();
        this.producerRepository = new producerRepository_1.ProducerRepository();
        this.farmRepository = new farmRepository_1.FarmRepository();
        this.farmCropRepository = new farmCropRepository_1.FarmCropRepository();
    }
    create(_a) {
        return __awaiter(this, arguments, void 0, function* ({ cpf_cnpj, producerName, farmName, city, state, totalArea, arableArea, vegetableArea, plantedCrops }) {
            if (!this.validateTotalFarmArea(totalArea, arableArea, vegetableArea)) {
                throw new Error('Área total deve ser maior ou igual a soma das áreas agriculturáveis e de vegetação.');
            }
            if (cpf_cnpj.length === 11) {
                if (!(0, validateCPF_1.validateCPF)(cpf_cnpj))
                    throw new Error('Invalid CPF');
            }
            else {
                if (!(0, validateCNPJ_1.validateCNPJ)(cpf_cnpj))
                    throw new Error('Invalid CNPJ');
            }
            // todo: validate crops
            let producer = yield this.producerRepository.create({ cpf_cnpj, name: producerName });
            if (producer == null)
                throw new Error('Failed to insert new Producer');
            let farm = yield this.farmRepository.create({ name: farmName, city, state, totalArea, arableArea, vegetableArea, producerId: producer.id });
            if (farm == null)
                throw new Error('Failed to insert new Farm');
            /* if(plantedCrops.length > 0 ){
                console.log(plantedCrops)
            } */
            let createdEntity = {
                id: producer.id,
                name: producer.name,
                cpf_cnpj: producer.cpf_cnpj,
                farm: farm
            };
            return createdEntity;
        });
    }
    get(cpf_cnpj) {
        return __awaiter(this, void 0, void 0, function* () {
            let ruralProducer = yield this.ruralProducerRepository.getByCpfOrCnpj(cpf_cnpj);
            if (ruralProducer === null)
                return null;
            let entity = {
                id: ruralProducer.producerId,
                name: ruralProducer.producerName,
                cpf_cnpj: ruralProducer.cpf_cnpj,
                farm: {
                    id: ruralProducer.farmId,
                    name: ruralProducer.farmName,
                    city: ruralProducer.city,
                    state: ruralProducer.state,
                    totalArea: ruralProducer.totalArea,
                    arableArea: ruralProducer.arableArea,
                    vegetableArea: ruralProducer.vegetableArea
                }
            };
            return entity;
        });
    }
    getAll() {
        return __awaiter(this, void 0, void 0, function* () {
            return yield this.ruralProducerRepository.getAll();
        });
    }
    delete(cpf_cnpj) {
        return __awaiter(this, void 0, void 0, function* () {
            let ruralProducer = yield this.ruralProducerRepository.getByCpfOrCnpj(cpf_cnpj);
            if (ruralProducer === null)
                return false;
            yield this.farmCropRepository.deleteByFarm(ruralProducer.farmId);
            yield this.farmRepository.delete(ruralProducer.farmId);
            yield this.producerRepository.delete(ruralProducer.producerId);
            return true;
        });
    }
    validateTotalFarmArea(totalArea, arableArea, vegetableArea) {
        return totalArea > arableArea + vegetableArea;
    }
}
exports.RuralProducerController = RuralProducerController;

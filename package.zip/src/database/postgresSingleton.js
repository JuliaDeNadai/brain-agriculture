"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const pg_1 = require("pg");
class PostgresSingleton {
    constructor() { }
    static getInstance() {
        if (!PostgresSingleton.instance) {
            PostgresSingleton.instance = new pg_1.Pool({
                user: process.env.DB_USERNAME,
                host: process.env.DB_HOST,
                database: process.env.DB_NAME,
                password: process.env.DB_PASSWORD,
                port: 5432,
            });
            PostgresSingleton.instance.on('connect', () => {
                console.log('Conectado ao banco de dados');
            });
            PostgresSingleton.instance.on('error', (err) => {
                console.error('Erro no banco de dados:', err);
                process.exit(-1);
            });
        }
        return PostgresSingleton.instance;
    }
    static closeConnection() {
        return __awaiter(this, void 0, void 0, function* () {
            if (PostgresSingleton.instance) {
                yield PostgresSingleton.instance.end();
                console.log('Conexão fechada com o banco de dados');
                PostgresSingleton.instance = null;
            }
        });
    }
}
exports.default = PostgresSingleton;

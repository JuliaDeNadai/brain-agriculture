"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.app = void 0;
require("express-async-errors");
const express_1 = __importDefault(require("express"));
const endpoints_1 = require("../endpoints");
const errorMiddleware_1 = require("../middlewares/errorMiddleware");
const swagger_ui_express_1 = __importDefault(require("swagger-ui-express"));
const swagger_output_json_1 = __importDefault(require("../../swagger_output.json"));
const app = (0, express_1.default)();
exports.app = app;
app.use(express_1.default.json());
app.use(endpoints_1.endpoints);
app.use('/api-docs', swagger_ui_express_1.default.serve, swagger_ui_express_1.default.setup(swagger_output_json_1.default));
app.use(errorMiddleware_1.errorMiddleware);

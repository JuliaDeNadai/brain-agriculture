"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ruralProducerMiddleware = ruralProducerMiddleware;
const express_validator_1 = require("express-validator");
function ruralProducerMiddleware() {
    return [
        (0, express_validator_1.body)('cpf_cnpj')
            .isLength({ min: 11 })
            .withMessage('CPF/CNPJ must be at least 11 chars long')
            .isLength({ max: 14 })
            .withMessage('CPF/CNPJ must be less than 14 chars long')
            .exists()
            .withMessage('CPF/CNPJ is required')
            .trim()
            .escape(),
        (0, express_validator_1.body)('producerName').matches('([a-zA-Z_\s]+)').withMessage('Invalid producer name').exists().withMessage('Producer name is required'),
        (0, express_validator_1.body)('farmName').matches('([a-zA-Z_\s]+)').withMessage('Invalid farm name').exists().withMessage('Farm name is required'),
        (0, express_validator_1.body)('city').matches('([a-zA-Z_\s]+)').withMessage('Invalid city').exists().withMessage('City is required'),
        (0, express_validator_1.body)('state').matches('([a-zA-Z_\s]+)').withMessage('Invalid state').exists().withMessage('State is required'),
        (0, express_validator_1.body)('totalArea').isNumeric().withMessage('Invalid total area.').exists().withMessage('Total area is required'),
        (0, express_validator_1.body)('arableArea').isNumeric().withMessage('Invalid arable area.').exists().withMessage('Arable area is required'),
        (0, express_validator_1.body)('vegetableArea').isNumeric().withMessage('Invalid vegetable area.').exists().withMessage('Vegetable area is required'),
        (0, express_validator_1.body)('plantedCrops').isArray().withMessage('Crop contain invalid value.'), //.isIn(['Soja', 'Milho', 'Algodão', 'Café', 'Cana de Açucar']).withMessage('Crop contain invalid value.'),
    ];
}

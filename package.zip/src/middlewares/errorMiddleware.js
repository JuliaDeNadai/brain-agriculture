"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.errorMiddleware = void 0;
const errorMiddleware = (error, request, response, next) => {
    var _a;
    console.log(error);
    let title = "";
    let detail = "";
    let statusCode = (_a = error.statusCode) !== null && _a !== void 0 ? _a : 500;
    title = error.title ? error.title : 'Internal Server Error';
    detail = error.detail ? error.detail : 'Um error não esperado ocorreu.';
    return response.status(statusCode).json({ title, detail });
};
exports.errorMiddleware = errorMiddleware;

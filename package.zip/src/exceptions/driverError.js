"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DriverError = void 0;
class DriverError extends Error {
    constructor(code, errno, sqlMessage, stack) {
        super(code);
        this.errno = errno;
        this.code = code;
        this.sqlMessage = sqlMessage;
        this.stack = stack;
    }
}
exports.DriverError = DriverError;

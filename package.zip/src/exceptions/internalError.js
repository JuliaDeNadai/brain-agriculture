"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InternalError = void 0;
class InternalError extends Error {
    constructor(title, detail, statusCode) {
        super(title);
        this.statusCode = statusCode;
        this.title = title;
        this.detail = detail;
    }
}
exports.InternalError = InternalError;

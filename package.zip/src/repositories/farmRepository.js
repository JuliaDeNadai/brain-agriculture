"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FarmRepository = void 0;
const postgresSingleton_1 = __importDefault(require("../database/postgresSingleton"));
class FarmRepository {
    constructor() {
        this.pool = postgresSingleton_1.default.getInstance();
    }
    create(_a) {
        return __awaiter(this, arguments, void 0, function* ({ name, city, state, totalArea, arableArea, vegetableArea, producerId }) {
            const result = yield this.pool.query(`INSERT INTO "Farm"
      ( 
        name,
        city,
        state,
        total_area,
        arable_area,
        vegetable_area,
        producer
      )VALUES(
        '${name}',
        '${city}',
        '${state}',
        ${totalArea},
        ${arableArea},
        ${vegetableArea},
        ${producerId}
      )
      RETURNING id`);
            if (result.rowCount === 0)
                return null;
            let { id } = result.rows[0];
            return { name, city, state, totalArea, arableArea, vegetableArea, id };
        });
    }
    delete(id) {
        return __awaiter(this, void 0, void 0, function* () {
            let result = yield this.pool.query(`DELETE FROM "Farm" where id = '${id}'`);
            if (result.rowCount === 0)
                return false;
            return true;
        });
    }
    getTotals() {
        return __awaiter(this, void 0, void 0, function* () {
            let result = yield this.pool.query(`
      select 
        count(*) total_farms,
        SUM(total_area) total_area,
        SUM(vegetable_area) planted_area,
        SUM(vegetable_area) vegetable_area,
        SUM(arable_area) arable_area
      from "Farm"
      `);
            return result.rows[0];
        });
    }
    getTotalFarmsGroupedByState() {
        return __awaiter(this, void 0, void 0, function* () {
            let result = yield this.pool.query(`
      select 
        state,
        count(*) total_farms
      from "Farm"
      group by state
      `);
            return result.rows;
        });
    }
    getTotalFarmsGroupedByCrops() {
        return __awaiter(this, void 0, void 0, function* () {
            let result = yield this.pool.query(`
        select 
          COUNT(*) total_farms,
          c."name" crop 
        from "Crop" c 
        join "Farm_Crop" fc on fc.crop = c.id 
        join "Farm" f on f.id = fc.farm 
        group by c.id 
      `);
            return result.rows;
        });
    }
    getDashboardData() {
        return __awaiter(this, void 0, void 0, function* () {
            const { total_farms, total_area, planted_area, arable_area, vegetable_area } = yield this.getTotals();
            const totalFarmsByState = yield this.getTotalFarmsGroupedByState();
            const totalFarmsGroupedByCrops = yield this.getTotalFarmsGroupedByCrops();
            return { total_farms, total_area, planted_area, arable_area, vegetable_area, totalFarmsByState, totalFarmsGroupedByCrops };
        });
    }
}
exports.FarmRepository = FarmRepository;

"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RuralProducerRepository = void 0;
const postgresSingleton_1 = __importDefault(require("../database/postgresSingleton"));
class RuralProducerRepository {
    constructor() {
        this.pool = postgresSingleton_1.default.getInstance();
    }
    create(_a) {
        return __awaiter(this, arguments, void 0, function* ({ cpf_cnpj, producerName, farmName, city, state, totalArea, arableArea, vegetableArea, plantedCrops }) {
            const result = yield this.pool.query(`INSERT INTO "Producer"
            ( 
              cpf_cnpj,
              producer_name,
              farm_name,
              city,
              state,
              total_area,
              arable_area,
              vegetable_area,
              planted_cropd
            )VALUES(
              '${cpf_cnpj}',
              '${producerName}',
              '${farmName}',
              '${city}',
              '${state}',
              ${totalArea},
              ${arableArea},
              ${vegetableArea},
              '${plantedCrops}'
            )`);
            if (result.rowCount === 0)
                return null;
            return { cpf_cnpj, producerName, farmName, city, state, totalArea, arableArea, vegetableArea, plantedCrops };
        });
    }
    getByCpfOrCnpj(cpf_cnpj) {
        return __awaiter(this, void 0, void 0, function* () {
            let result = yield this.pool.query(`
      SELECT 
        p.id as "producerId",
        p.cpf_cnpj cpf_cnpj,
        p.name as "producerName",
        f.id as "farmId",
        f."name" as "farmName",
        f.city city,
        f.state state,
        f.total_area,
        f.arable_area,
        f.vegetable_area
      FROM "Producer" p 
      JOIN "Farm" f on f.producer = p.id  
      WHERE cpf_cnpj = '${cpf_cnpj}'`);
            if (result.rowCount === 0)
                return null;
            return result.rows[0];
        });
    }
    getAll() {
        return __awaiter(this, void 0, void 0, function* () {
            let result = yield this.pool.query(`
      SELECT 
        p.cpf_cnpj cpf_cnpj,
        p.name as "producerName",
        f."name" as "farmName",
        f.city city,
        f.state state,
        f.total_area,
        f.arable_area,
        f.vegetable_area
      FROM "Producer" p 
      JOIN "Farm" f on f.producer = p.id `);
            return result.rows;
        });
    }
}
exports.RuralProducerRepository = RuralProducerRepository;

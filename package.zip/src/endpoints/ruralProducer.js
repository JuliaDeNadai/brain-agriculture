"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ruralProducerEnpoint = void 0;
const express_1 = __importDefault(require("express"));
const ruralProducerController_1 = require("../controllers/ruralProducerController");
const ruralProducerMiddleware_1 = require("../middlewares/ruralProducerMiddleware");
const express_validator_1 = require("express-validator");
const ruralProducerEnpoint = express_1.default.Router();
exports.ruralProducerEnpoint = ruralProducerEnpoint;
const controller = new ruralProducerController_1.RuralProducerController();
ruralProducerEnpoint.route('/')
    .post((0, ruralProducerMiddleware_1.ruralProducerMiddleware)(), (request, response) => __awaiter(void 0, void 0, void 0, function* () {
    const errors = (0, express_validator_1.validationResult)(request);
    if (!errors.isEmpty())
        return response.status(400).json({ errors: errors.array() });
    const { cpf_cnpj, producerName, farmName, city, state, totalArea, arableArea, vegetableArea, plantedCrops } = request.body;
    let producer = yield controller.create({
        cpf_cnpj,
        producerName,
        farmName,
        city,
        state,
        totalArea,
        arableArea,
        vegetableArea,
        plantedCrops
    });
    if (producer === null)
        return response.sendStatus(500);
    response.status(201).json(producer);
}))
    .get((request, response) => __awaiter(void 0, void 0, void 0, function* () {
    let producers = yield controller.getAll();
    response.status(200).json(producers);
}));
ruralProducerEnpoint.route('/:cpf_cnpj')
    .get((request, response) => __awaiter(void 0, void 0, void 0, function* () {
    let { cpf_cnpj } = request.params;
    let producer = yield controller.get(cpf_cnpj);
    if (producer === null)
        return response.sendStatus(404);
    response.status(200).json(producer);
}))
    .delete((request, response) => __awaiter(void 0, void 0, void 0, function* () {
    let { cpf_cnpj } = request.params;
    let result = yield controller.delete(cpf_cnpj);
    if (result)
        return response.sendStatus(204);
    response.sendStatus(404);
}));

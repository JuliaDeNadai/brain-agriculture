"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.endpoints = void 0;
const express_1 = __importDefault(require("express"));
const healthckeck_1 = require("./healthckeck");
const ruralProducer_1 = require("./ruralProducer");
const dashboard_1 = require("./dashboard");
const endpoints = express_1.default.Router();
exports.endpoints = endpoints;
endpoints.use('/api/healthcheck', healthckeck_1.healthCheckEnpoint);
endpoints.use('/api/ruralProducer', ruralProducer_1.ruralProducerEnpoint);
endpoints.use('/api/dashboard', dashboard_1.dashboardEnpoint);
